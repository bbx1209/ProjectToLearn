//
//  ICFAppDelegate.h
//  WhackACac
//
//  Created by Kyle Richter on 7/2/12.
//  Copyright (c) 2012 Dragon Forged Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ICFViewController;

@interface ICFAppDelegate : UIResponder <UIApplicationDelegate>
{
    
    
    
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navController;
@property (strong, nonatomic) ICFViewController *viewController;

@end
